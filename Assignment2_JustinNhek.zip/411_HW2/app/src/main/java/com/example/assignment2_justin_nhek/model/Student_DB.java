package com.example.assignment2_justin_nhek.model;

import java.util.ArrayList;

public class Student_DB {
    private static final Student_DB ourInstance = new Student_DB();

    private ArrayList<Student> mStudents;

    public static Student_DB getInstance() {return ourInstance;}

    private Student_DB(){createStudentObjects();}

    public ArrayList<Student> getStudents(){return mStudents;}

    public void setStudents(ArrayList<Student> students){mStudents = students;}

    private void createStudentObjects(){

        Student studetObject;
        ArrayList<Enroll_Course> courses = new ArrayList<Enroll_Course>();
        mStudents = new ArrayList<Student>();

        studetObject  = new Student("Justin", "Nhek", 889910774);
        courses.add(new Enroll_Course("CPSC 411", "B"));
        courses.add(new Enroll_Course("CPSC 349", "B"));
        studetObject.setCourses(courses);

        mStudents.add(studetObject);


        studetObject  = new Student("Kent", "Dent", 654236842);
        courses = new ArrayList<Enroll_Course>();
        courses.add(new Enroll_Course("CPSC 411", "A"));
        courses.add(new Enroll_Course("CPSC 121", "C-"));
        studetObject.setCourses(courses);
        
        mStudents.add(studetObject);

        studetObject  = new Student("Johnny", "Appleseed", 112255998);
        courses = new ArrayList<Enroll_Course>();
        courses.add(new Enroll_Course("CPSC 440", "B"));
        courses.add(new Enroll_Course("CPSC 315", "B"));
        studetObject.setCourses(courses);

        mStudents.add(studetObject);
    }
}
